g_turndata = {
	"regions": [],
	"kingdoms": {},
	"communications": [],
	"characters": [],
	"armies": [],
	"pirate": {},
	"tivar": {}
};

function generateSampleGamedata() {
	let dimensions = ["population", "food", "army", "navy", "gold"];
	let shares = {};
	let totalshares = {};
	for (let dimension of dimensions) totalshares[dimension] = 0;
	for (var k of g_gamestate.kingdoms) {
		shares[k.name] = {};
		for (let dimension of dimensions) {
			shares[k.name][dimension] = Math.random() + 0.5;
			totalshares[dimension] += shares[k.name][dimension];
		}
	}
	for (let i = 0; i < g_regions.length; i++) {
		if (g_regions[i].type == "land") {
			let kingdom = "";
			for (var k of g_gamestate.kingdoms) {
				if (k.core_regions.includes(i)) kingdom = k;
			}
			g_turndata.regions.push({
				"population": 23000000 / totalshares.population * shares[kingdom.name].population / kingdom.core_regions.length,
				"kingdom": kingdom.name,
				"unrest_popular": Math.random() / 2 + 0.1,
				"noble": {
					"name": "Sir Iassac Newton",
					"profile": "Conquest",
					"type": "Burgher",
					"unrest": Math.random() / 2 + 0.1,
				},
				"constructions": [
					{"type": "shipyard", "original_cost": 33},
					{"type": "temple", "religion": "Northern (Alyrja)", "original_cost": 33},
					{"type": "fortifications", "original_cost": 22}
				],
				"food": 23000000 * 9 / totalshares.food * shares[kingdom.name].food / kingdom.core_regions.length,
				"harvest": 7.5
			});
		} else {
			g_turndata.regions.push({});
		}
	}
}
